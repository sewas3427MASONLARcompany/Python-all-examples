adi=input("Adınızı giriniz:")
soyadi=input("Soyadınızı giriniz:")

print("Merhaba "+adi+" "+soyadi+" Hoş geldiniz");