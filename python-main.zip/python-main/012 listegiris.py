ogrenci_list=["Ali","Can",623,5000]

print(type(ogrenci_list))

print(ogrenci_list[0])
print(ogrenci_list[1])
print(ogrenci_list[2])
print(ogrenci_list[3])

