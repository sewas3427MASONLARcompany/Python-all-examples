dolar = float(input("Dolar kurunu giriniz:"))
miktarDolar=float(input("Miktarı giriniz:"))

euro = float(input("Euro kurunu giriniz:"))
miktarEuro=float(input("Miktarı giriniz:"))


toplam= dolar*miktarDolar+ euro*miktarEuro
print("Toplam:",toplam," TL")