x= float(input("x değerini giriniz:"))

y=x**3+2*x**2+5*x+2

print("Sonuç:",y)