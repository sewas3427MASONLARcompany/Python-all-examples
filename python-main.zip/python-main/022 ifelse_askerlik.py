
yas=int(input("Yaş giriniz:"))
if(yas>=18):
 print("Askere gidebilirsiniz")
else:
 print("Yaşınız daha küçük")    