not1= int(input("1. notu giriniz:"))
not2= int(input("2. notu giriniz:"))

ortalama=(not1+not2)/2

print("Ortalama=",ortalama)