x=3+2
y=3*2
z=10%4


print('x=',x)
print('y=',y)
print('z=',z)
