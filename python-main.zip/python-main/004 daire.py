pi=3.14
r=3

cevre=2*pi*r
alan=pi*r*r

print("Alan=",alan)
print("Çevre=",cevre)