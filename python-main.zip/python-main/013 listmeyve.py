meyve=["elma","nar","muz","kivi","çilek","armut"]

print(meyve[0]) #ilk elemana erişim
print(meyve[4]) #son elemana erişim

print(meyve[1:4]) # index 0'dan başlayıp 4'ün bir eksiğine kadar gider
# nar, muz, kivi yazar

print(meyve[0:3]) # elma, nar, muz yazar
print(meyve[:3])  #elma, nar, muz yazar
print(meyve[2:]) #muz, kivi, çilek
print(meyve[0:5:2])