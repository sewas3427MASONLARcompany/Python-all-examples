not1=50
not2=70
not3=80

ortalama=(not1+not2+not3)/3

print("Ortalama=",ortalama)

