sonuc=['G','E','Ç','T','İ']

print(sonuc[0])
print(sonuc[:])

print(sonuc[0:3]) #sadece GEC yazar
print(sonuc[:-1]) # sondan ilk elemana -1 ile ulaşırız, GECT
print(sonuc[:4]) # GECT yazar
print(sonuc[-4:-1])