print('merhaba')
